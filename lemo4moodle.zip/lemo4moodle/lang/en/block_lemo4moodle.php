﻿<?php
$string['pluginname'] = 'Lemo4Moodle';
$string['lemo4moodle'] = 'Lemo4Moodle';
$string['lemo4moodle:addinstance'] = 'Add a new Lemo4moodle block';
$string['lemo4moodle:myaddinstance'] = 'Add a new Lemo4moodle block to the My Moodle page';
$string['blockstring'] = 'Hier könnte Ihre Werbung stehen';
$string['content'] = 'CONTENT SETTINGS';
$string['blocktitle'] = 'blocktitletest';
$string['text'] = 'Inhalt des Blocks';
$string['privacy:metadata'] = 'The lemo4moodle block only displays existing data for actions inside the course.';
