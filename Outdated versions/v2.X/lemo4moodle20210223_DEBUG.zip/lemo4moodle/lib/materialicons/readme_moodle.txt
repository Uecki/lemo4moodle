Link: https://fonts.googleapis.com/icon?family=Material+Icons
