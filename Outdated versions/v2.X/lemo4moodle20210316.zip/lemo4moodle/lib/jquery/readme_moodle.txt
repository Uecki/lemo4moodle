Link for JQueryUI CSS: https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css
Link for JQueryUI JS: https://code.jquery.com/ui/1.12.1/jquery-ui.js
Link for JQuery JS: https://code.jquery.com/jquery-1.12.4.js
