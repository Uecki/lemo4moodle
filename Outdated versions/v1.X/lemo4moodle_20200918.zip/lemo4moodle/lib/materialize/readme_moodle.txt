Link for JS: https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js
Links for CSS: https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css
